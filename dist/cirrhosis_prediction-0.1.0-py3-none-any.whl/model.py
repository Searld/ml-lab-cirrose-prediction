import pandas as pd
import numpy as np
import logging
import os
import joblib  # Для сохранения Random Forest
import fire
from sklearn.ensemble import RandomForestClassifier

# 1. Настройка логирования (требование: файл в ./data/log_file.log)
os.makedirs('./data', exist_ok=True)
logging.basicConfig(
    filename='./data/log_file.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class My_Classifier_Model:
    """Класс для обучения и предсказания выживаемости (Homework 1)."""

    def train(self, dataset: str):
        """
        Метод обучения.
        Запуск: python model.py train --dataset=data/train.csv
        """
        try:
            logger.info(f"Начало обучения. Файл: {dataset}")
            train = pd.read_csv(dataset)
            
            X = train.drop(['id', 'Status'], axis=1)
            y = train['Status']
            
            # Твой препроцессинг из Юпитера
            X = pd.get_dummies(X)
            
            # Сохраним список колонок, чтобы при предсказании не было ошибок
            os.makedirs('./model', exist_ok=True)
            joblib.dump(X.columns.tolist(), './model/features.pkl')
            
            # Обучение
            model = RandomForestClassifier(n_estimators=100, random_state=42)
            model.fit(X, y)
            
            # Сохранение артефактов (требование задания)
            joblib.dump(model, './model/model.pkl')
            
            logger.info("Модель успешно обучена и сохранена в ./model/model.pkl")
            print("✅ Обучение завершено успешно.")
            
        except Exception as e:
            logger.error(f"Ошибка при обучении: {e}")
            raise

    def predict(self, dataset: str):
        """
        Метод предсказания.
        Запуск: python model.py predict --dataset=data/test.csv
        """
        try:
            logger.info(f"Начало предсказания. Файл: {dataset}")
            
            # Загрузка модели и колонок
            model = joblib.load('./model/model.pkl')
            feature_cols = joblib.load('./model/features.pkl')
            
            test = pd.read_csv(dataset)
            ids = test['id']
            
            # Твой препроцессинг
            test_processed = pd.get_dummies(test.drop(['id'], axis=1))
            test_processed = test_processed.reindex(columns=feature_cols, fill_value=0)
            
            # Предсказание вероятностей
            predictions = model.predict_proba(test_processed)
            
            # Формируем результат (Status_C, Status_CL, Status_D)
            submission = pd.DataFrame(predictions, columns=[f'Status_{c}' for c in model.classes_])
            submission.insert(0, 'id', ids)
            
            # Сохранение результата (требование задания)
            submission.to_csv('./data/results.csv', index=False)
            
            logger.info("Предсказания сохранены в ./data/results.csv")
            print("✅ Предсказания готовы (./data/results.csv)")

        except Exception as e:
            logger.error(f"Ошибка при предсказании: {e}")
            raise

if __name__ == '__main__':
    fire.Fire(My_Classifier_Model)